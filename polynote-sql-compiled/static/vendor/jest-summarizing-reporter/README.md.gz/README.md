# Jest summarizing reporter

Vendored by jindig to prevent unnecessary dependency. 

See homepage for details: https://github.com/sunfit/jest-summary-reporter

# License

Unlicense